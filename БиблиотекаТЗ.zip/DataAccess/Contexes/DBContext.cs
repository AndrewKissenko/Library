﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using DataAccess.Interfaces;
using DataAccess.Models;

namespace DataAccess.Contexes
{
    //Here`s my main DB
    public class DBContext : IDbContext
    {
        private readonly SqlConnection connection;

        public DBContext()
        {
        }

        public DBContext(string connectionString)
        {
            connection = new SqlConnection(connectionString);
            CreateDbIFNotExists();
        }
        //retrieves all authors from DB
        public List<Author> GetAuthors()
        {
            var authorList = new List<Author>();
            connection.Open();

            var query = "Select * From Authors";
            var command = new SqlCommand(query, connection);
            using (var dataReader = command.ExecuteReader())
            {
                while (dataReader.Read())
                    authorList.Add(new Author
                    {
                        Id = Convert.ToInt32(dataReader["AuthorId"]),
                        Name = Convert.ToString(dataReader["Name"]),
                        LName = Convert.ToString(dataReader["LName"])
                    });
            }

            connection.Close();
            return authorList;
        }
        ////retrieves an authors from DB
        public Author GetAuthor(int id)
        {
            var query = $"Select * From Authors Where AuthorId='{id}'";
            var command = new SqlCommand(query, connection);
            connection.Open();
            using (var dataReader = command.ExecuteReader())
            {
                while (dataReader.Read())
                    return new Author
                    {
                        Id = Convert.ToInt32(dataReader["AuthorId"]),
                        Name = Convert.ToString(dataReader["Name"]),
                        LName = Convert.ToString(dataReader["LName"])
                    };
            }

            connection.Close();
            return null;
        }
        //query to add a new user
        public void AddUser(User user)
        {
            var query = $"Insert into Users(LogIn,Password,IsAdmin) values('{user.LogIn}','{user.Password}','{user.IsAdmin}')";

            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
        //query to add a new author
        public decimal AddAuthor(Author author)
        {
            var query = $"Insert into Authors ({nameof(Author.Name)},{nameof(Author.LName)}) values('{author.Name}','{author.LName}')";
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            var query2 = $"SELECT IDENT_CURRENT('Authors')";
            connection.Open();
            using (SqlCommand command = new SqlCommand(query2, connection))
            {
                var idNum = (decimal)command.ExecuteScalar();
                connection.Close();
                return idNum;
            }
        }
        //query to add a new book
        public void AddBook(Book book)
        {
            string query = $"Insert Into Books (Name) Values ('{book.Name}')";
            connection.Open();
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.CommandType = CommandType.Text;
                command.ExecuteNonQuery();
                connection.Close();
            }
            connection.Open();
            string query3 = $"SELECT IDENT_CURRENT('Books')";
            decimal currentBookId;
            using (SqlCommand command = new SqlCommand(query3, connection))
            {
                currentBookId = (decimal)command.ExecuteScalar();
                connection.Close();
            }
            foreach (var a in book.Authors)
            {
                var id = AddAuthor(a);
                string query2 = $"Insert Into AuthorsToBooks (BookId,AuthorId) Values ('{currentBookId}','{id}')";
                using (SqlCommand command = new SqlCommand(query2, connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
        }
        //query to delete an author via ID
        public void DeleteAuthor(int id)
        {
            var query = $"Delete From Authors Where AuthorId='{id}'";
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
        //query to delete a book via ID
        public void RemoveBook(int id)
        {
            var query = $"Delete From AuthorsToBooks Where BookId='{id}'";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            var query3 = $" Delete From BookHistory Where BookId='{id}'";
            using (SqlCommand command = new SqlCommand(query3, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            var query2 = $" Delete From Books Where BookId='{id}'";
            using (SqlCommand command = new SqlCommand(query2, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        

        }
        //query to delete a user via ID
        public void DeleteUser(int id)
        {
            var query = $"Delete From Users Where UserId='{id}'";
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
        //query to retrieve all books available for a user to take from library
        public List<Book> GetAllAvailable()
        {
            var books = new List<Book>();
            var query = "select BookId,Name,IsAvalaible from Books where IsAvalaible=1";
            var command = new SqlCommand(query, connection);
            connection.Open();
            using (var dataReader = command.ExecuteReader())
            {
                while (dataReader.Read())
                    books.Add(new Book
                    {
                        Id = Convert.ToInt32(dataReader["BookId"]),
                        Name = Convert.ToString(dataReader["Name"]),
                        IsAvalaible = Convert.ToBoolean(dataReader["IsAvalaible"])
                    });
            }

            connection.Close();
            connection.Open();
            foreach (var b in books)
            {
                var query2 = "select a.AuthorId, a.Name,a.LName from Books as b " +
                             "join AuthorsToBooks as ab on ab.BookId = b.BookId " +
                             "join Authors as a on a.AuthorId = ab.AuthorId " +
                             $"where b.BookId = {b.Id}";

                var command2 = new SqlCommand(query2, connection);

                using (var dataReader = command2.ExecuteReader())
                {
                    while (dataReader.Read())
                        b.Authors.Add(new Author
                        {
                            Id = Convert.ToInt32(dataReader["AuthorId"]),
                            Name = Convert.ToString(dataReader["Name"]),
                            LName = Convert.ToString(dataReader["LName"])
                        });
                }
            }

            connection.Close();
            return books;

        }
        //retrieves all books from DB
        public List<Book> GetAllBooks()
        {
            var books = new List<Book>();
            var query = "select BookId,Name,IsAvalaible from Books";

            var command = new SqlCommand(query, connection);
            connection.Open();
            using (var dataReader = command.ExecuteReader())
            {
                while (dataReader.Read())
                    books.Add(new Book
                    {
                        Id = Convert.ToInt32(dataReader["BookId"]),
                        Name = Convert.ToString(dataReader["Name"]),
                        IsAvalaible = Convert.ToBoolean(dataReader["IsAvalaible"])
                    });
            }

            connection.Close();
            connection.Open();
            foreach (var b in books)
            {
                var query2 = "select a.AuthorId, a.Name,a.LName from Books as b " +
                             "join AuthorsToBooks as ab on ab.BookId = b.BookId " +
                             "join Authors as a on a.AuthorId = ab.AuthorId " +
                             $"where b.BookId = {b.Id}";

                var command2 = new SqlCommand(query2, connection);

                using (var dataReader = command2.ExecuteReader())
                {
                    while (dataReader.Read())
                        b.Authors.Add(new Author
                        {
                            Id = Convert.ToInt32(dataReader["AuthorId"]),
                            Name = Convert.ToString(dataReader["Name"]),
                            LName = Convert.ToString(dataReader["LName"])
                        });
                }
            }

            connection.Close();
            return books;
        }
        //get book and its authors and history
        public Book GetBook(int id)
        {
            var query = $"select*from Books where BookId='{id}'";
            Book book = null;
            var command = new SqlCommand(query, connection);
            connection.Open();
            using (var dataReader = command.ExecuteReader())
            {
               
                while (dataReader.Read())
                    book = new Book
                    {
                        Id = Convert.ToInt32(dataReader["BookId"]),
                        Name = Convert.ToString(dataReader["Name"]),
                        IsAvalaible = Convert.ToBoolean(dataReader["IsAvalaible"])
                    };
            }

            connection.Close();
            connection.Open();

            var query2 = "select a.AuthorId, a.Name,a.LName from Books as b " +
                         "join AuthorsToBooks as ab on ab.BookId = b.BookId " +
                         "join Authors as a on a.AuthorId = ab.AuthorId " +
                         $"where b.BookId = {book.Id}";

            var command2 = new SqlCommand(query2, connection);

            using (var dataReader = command2.ExecuteReader())
            {
                while (dataReader.Read())
                    book.Authors.Add(new Author
                    {
                        Id = Convert.ToInt32(dataReader["AuthorId"]),
                        Name = Convert.ToString(dataReader["Name"]),
                        LName = Convert.ToString(dataReader["LName"])
                    });
            }

            connection.Close();

            var query3 = "select b.BookId,b.[Name],u.UserId,u.Login,TimeTaken,TimeReturned " +
                       "from Books as b " +
                       "join BookHistory as bk on bk.BookId = b.BookId " +
                       "join Users as u on u.UserId = bk.UserId " +
                       $"where b.BookId = {id}";


            var command3 = new SqlCommand(query3, connection);
            connection.Open();
            using (var dataReader = command3.ExecuteReader())
            {
                while (dataReader.Read())
                {
                    BookHistory bookHistory = new BookHistory
                    {
                        BookId = Convert.ToInt32(dataReader["BookId"]),
                        BookName = Convert.ToString(dataReader["Name"]),
                        UserId = Convert.ToInt32(dataReader["UserId"]),
                        UserLogIn = Convert.ToString(dataReader["LogIn"]),
                        TakenOn = Convert.ToDateTime(dataReader["TimeTaken"]),
                    };
                    try
                    {
                        bookHistory.ReturnedOn = Convert.ToDateTime(dataReader["TimeReturned"]).ToString();
                    }
                    catch
                    {
                        bookHistory.ReturnedOn = "not returned yet";
                    }
                    book.BookHistories.Add(bookHistory);
                }
            }

            connection.Close();
            return book;
        }
        //get user
        public User GetUser(int id)
        {
            var query = $"Select * From Users where UserId={id}";
            User user = null;
            connection.Open();
            using (var command = new SqlCommand(query, connection))
            {
                using (var dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                        user = new User
                        {
                            Id = Convert.ToInt32(dataReader["UserId"]),
                            LogIn = Convert.ToString(dataReader["LogIn"]),
                            Password = Convert.ToString(dataReader["Password"]),
                            IsAdmin = Convert.ToBoolean(dataReader["IsAdmin"])
                        };
                }

                connection.Close();
            }

            connection.Open();

            var query2 = "select b.BookId, b.Name,b.IsAvalaible from Books as b " +
                         "join BookHistory as bh on bh.BookId = b.BookId " +
                         "join Users as u on u.UserId = bh.UserId " +
                         $"where u.UserId={id} and b.IsAvalaible=0";

            var command2 = new SqlCommand(query2, connection);
            
            using (var dataReader = command2.ExecuteReader())
            {
                while (dataReader.Read())
                    user.BooksTaken.Add(new Book
                    {
                        Id = Convert.ToInt32(dataReader["BookId"]),
                        Name = Convert.ToString(dataReader["Name"]),
                        IsAvalaible = Convert.ToBoolean(dataReader["IsAvalaible"]),
                    });
            }
            connection.Close();

            connection.Open();
            foreach (var b in user.BooksTaken)
            {
                var query3 = "select a.AuthorId, a.Name,a.LName from Books as b " +
                             "join AuthorsToBooks as ab on ab.BookId = b.BookId " +
                             "join Authors as a on a.AuthorId = ab.AuthorId " +
                             $"where b.BookId = {b.Id}";

                var command3 = new SqlCommand(query3, connection);

                using (var dataReader = command3.ExecuteReader())
                {
                    while (dataReader.Read())
                        b.Authors.Add(new Author
                        {
                            Id = Convert.ToInt32(dataReader["AuthorId"]),
                            Name = Convert.ToString(dataReader["Name"]),
                            LName = Convert.ToString(dataReader["LName"])
                        });
                }
            }

            connection.Close();

            return user;
        }
        //get users from DB
        public List<User> GetUsers()
        {
            var query = "Select * From Users";
            var command = new SqlCommand(query, connection);
            connection.Open();
            using (var dataReader = command.ExecuteReader())
            {
                var listUsers = new List<User>();

                while (dataReader.Read())
                    listUsers.Add(new User
                    {
                        Id = Convert.ToInt32(dataReader["UserId"]),
                        LogIn = Convert.ToString(dataReader["LogIn"]),
                        Password = Convert.ToString(dataReader["Password"]),
                        IsAdmin=Convert.ToBoolean(dataReader["IsAdmin"])
                     
                    });
                connection.Close();
                return listUsers;
            }
        }
        //query to return taken book to library and update book history
        public void ReturnBookToLib(int BookId, int UserId)
        {
            var query =
                $"update BookHistory set TimeReturned = '{DateTime.Now.Date.ToString("MM/dd/yyyy")}', UserId='{UserId}' where BookId={BookId} and UserId= {UserId}";
            var query2 = $"update Books set IsAvalaible='1' where BookId='{BookId}'";
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            using (var command = new SqlCommand(query2, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
        //query to  take book from library and update book history
        public void TakeBookFromLib(int BookId, int UserId)
        {
            var query =
                $"insert into BookHistory (BookId,UserId,TimeTaken) values ('{BookId}','{UserId}','{DateTime.Now.Date.ToString("yyyy-MM-dd HH:mm:ss")}')";
            var query2 = $"update Books set IsAvalaible=0 where BookId='{BookId}'";                                                
            using (var command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            using (var command = new SqlCommand(query2, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
        //update book 
        public void UpdateBook(int oldBookId, Book newBook)
        {
            string query = $"Update Books SET Name='{newBook.Name}', {nameof(newBook.IsAvalaible)}='{newBook.IsAvalaible}' Where BookId='{oldBookId}'";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
        //creates DB if it is not created yet 
        private void CreateDbIFNotExists()
        {
            var dropCreateDb = File.ReadAllText("DataBaseScrypts\\CreateDatabase.sql");
            var createTables = File.ReadAllText("DataBaseScrypts\\CreateTables.sql");
            var masterConnection =
                new SqlConnection(
                    @"Data Source = (localdb)\MSSQLLocalDB;Initial Catalog=Master;Integrated Security=True;Connect Timeout=30;");
            masterConnection.Open();

            var command = new SqlCommand(dropCreateDb, masterConnection);
            command.ExecuteNonQuery();
            masterConnection.Close();

            connection.Open();
            command = new SqlCommand(createTables, connection);
            command.ExecuteNonQuery();
            connection.Close();
        }
    }
}