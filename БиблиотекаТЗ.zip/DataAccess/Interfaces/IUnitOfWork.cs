﻿using DataAccess.Models;
using DataAccess.Repositories;

namespace DataAccess.Interfaces
{
    public interface IUnitOfWork
    {
        IRepository<Author> Authors { get; }
        BookRepository Books { get; }
        IRepository<User> Users { get; }
        IUserBookOperations UserBookOperations { get; }
    }
}