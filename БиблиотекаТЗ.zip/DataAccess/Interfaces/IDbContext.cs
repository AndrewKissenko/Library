﻿using System.Collections.Generic;
using DataAccess.Models;

namespace DataAccess.Interfaces
{
    public interface IDbContext
    {
        #region User

        void AddUser(User user);
        void DeleteUser(int id);
        User GetUser(int id);
        List<User> GetUsers();
        void TakeBookFromLib(int BookId, int UserId);
        void ReturnBookToLib(int BookId, int UserId);

        #endregion

        #region Author

        decimal AddAuthor(Author author);
        void DeleteAuthor(int id);
        List<Author> GetAuthors();
        Author GetAuthor(int id);

        #endregion

        #region Book

        void AddBook(Book book);
        void RemoveBook(int id);
        List<Book> GetAllBooks();
        List<Book> GetAllAvailable();
        Book GetBook(int id);
        void UpdateBook(int oldIdBook, Book newBook);

        #endregion
    }
}