﻿namespace DataAccess.Interfaces
{
    public interface IUserBookOperations
    {
        void TakeBookFromLib(int BookId, int UserId);
        void ReturnBookToLib(int BookId, int UserId);
    }
}