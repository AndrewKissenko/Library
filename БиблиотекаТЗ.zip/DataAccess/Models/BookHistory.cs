﻿using System;

namespace DataAccess.Models
{
    public class BookHistory
    {
        public int BookId { get; set; }
        public string BookName { get; set; }
        public int UserId { get; set; }
        public string UserLogIn { get; set; }
        public DateTime TakenOn { get; set; }
        public string ReturnedOn { get; set; } = "not returned yet";
    }
}