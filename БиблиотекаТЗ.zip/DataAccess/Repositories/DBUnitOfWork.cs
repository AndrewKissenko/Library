﻿using DataAccess.Contexes;
using DataAccess.Interfaces;
using DataAccess.Models;

namespace DataAccess.Repositories
{
    public class DBUnitOfWork : IUnitOfWork
    { ////here is the layer to init repositories
        private readonly DBContext db;
        private AuthorRepository authorRepository;
        private BookRepository bookRepository;
        private UserBookOperationRepository userBookOperationRepository;
        private UserRepository userRepository;

        public DBUnitOfWork(string connectionString)
        {
            db = new DBContext(connectionString);
        }
        //init author rep
        public IRepository<Author> Authors
        {
            get
            {
                if (authorRepository == null)
                    authorRepository = new AuthorRepository(db);
                return authorRepository;
            }
        }
        //init book rep
        public BookRepository Books
        {
            get
            {
                if (bookRepository == null)
                    bookRepository = new BookRepository(db);
                return bookRepository;
            }
        }
        ////init user rep
        public IRepository<User> Users
        {
            get
            {
                if (userRepository == null)
                    userRepository = new UserRepository(db);
                return userRepository;
            }
        }
        //init UserBookOperations rep
        public IUserBookOperations UserBookOperations
        {
            get
            {
                if (userBookOperationRepository == null)
                    userBookOperationRepository = new UserBookOperationRepository(db);
                return userBookOperationRepository;
            }
        }
       
    }
}