﻿using System.Collections.Generic;
using DataAccess.Interfaces;
using DataAccess.Models;

namespace DataAccess.Repositories
{
    public class BookRepository : IRepository<Book>
    {
        private readonly IDbContext dBContext;

        public BookRepository(IDbContext dBContext)
        {
            this.dBContext = dBContext;
        }
        //get all books from db
        public IEnumerable<Book> GetAll()
        {
            return dBContext.GetAllBooks();
        }
        //get all available books from db
        public IEnumerable<Book> GetAllAvailable()
        {
            return dBContext.GetAllAvailable();
        }
        //get a book 
        public Book Get(int id)
        {
            return dBContext.GetBook(id);
        }
        //add book
        public void Add(Book book)
        {
            dBContext.AddBook(book);
        }
        //delete book
        public void Remove(int id)
        {
            dBContext.RemoveBook(id);
        }
        //update book
        public void UpdateBook(int oldIdBook, Book newBook)
        {
            dBContext.UpdateBook(oldIdBook, newBook);
        }

 
    }
}