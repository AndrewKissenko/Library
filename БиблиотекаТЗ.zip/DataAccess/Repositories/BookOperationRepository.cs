﻿using DataAccess.Interfaces;

namespace DataAccess.Repositories
{
    public class UserBookOperationRepository : IUserBookOperations
    {
        private readonly IDbContext dBContext;

        public UserBookOperationRepository(IDbContext dBContext)
        {
            this.dBContext = dBContext;
        }
        //take book from lib
        public void TakeBookFromLib(int BookId, int UserId)
        {
            dBContext.TakeBookFromLib(BookId, UserId);
        }
        //return book
        public void ReturnBookToLib(int BookId, int UserId)
        {
            dBContext.ReturnBookToLib(BookId, UserId);
        }
    }
}