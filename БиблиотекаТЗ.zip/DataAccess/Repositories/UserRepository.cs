﻿using System.Collections.Generic;
using DataAccess.Interfaces;
using DataAccess.Models;

namespace DataAccess.Repositories
{
    public class UserRepository : IRepository<User>
    {
        private readonly IDbContext dBContext;

        public UserRepository(IDbContext dBContext)
        {
            this.dBContext = dBContext;
        }
        //get all
        public IEnumerable<User> GetAll()
        {
            return dBContext.GetUsers();
        }
        //get user
        public User Get(int id)
        {
            return dBContext.GetUser(id);
        }
        //add user
        public void Add(User user)
        {
            dBContext.AddUser(user);
        }
        //delete user
        public void Remove(int id)
        {
            dBContext.DeleteUser(id);
        }
    }
}