﻿using System.Collections.Generic;
using DataAccess.Interfaces;
using DataAccess.Models;

namespace DataAccess.Repositories
{
    public class AuthorRepository : IRepository<Author>
    {
        private readonly IDbContext dBContext;

        public AuthorRepository(IDbContext dBContext)
        {
            this.dBContext = dBContext;
        }
        //get all authors
        public IEnumerable<Author> GetAll()
        {
            return dBContext.GetAuthors();
        }
        //get an author
        public Author Get(int id)
        {
            return dBContext.GetAuthor(id);
        }
        //add a new author
        public void Add(Author author)
        {
            dBContext.AddAuthor(author);
        }
        //delete an author
        public void Remove(int id)
        {
            dBContext.DeleteAuthor(id);
        }
    }
}