﻿using DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Interfaces
{
	public interface IDbContext
	{
		#region User
		void AddUser(string login, string password);
		void DeleteUser(int id);
		User GetUser(int id);
		List<User> GetUsers();
		#endregion

		void AddAuthor(Author author);
		void DeleteAuthor(int id);
		void Add_Book(Book book);
		void DeleteBook(int id);
		List<Book> GetAllBooks();
		Book GetBook(int id);
		void UpdateBook(int oldIdBook, Book newBook);
		void TakeBookFromLib(int BookId, int UserId);
		void ReturnBookToLib(int BookId);
		BookHistory GetBookHistory(int BookId);


	}
}
