﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Models
{
	public class Book
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public bool IsAvalaible { get; set; }
		public List<Author> Authors { get; set; }
		public Book()
		{
			Authors = new List<Author>();
			IsAvalaible = true;
		}

	}
}
