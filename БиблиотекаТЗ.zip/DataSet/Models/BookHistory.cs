﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Models
{
	public class BookHistory
	{
		public int BookId { get; set; }
		public string BookName { get; set; }
		public int UserId { get; set; }
		public string UserLogIn { get; set; }
		public DateTime TakenOn { get; set; } = DateTime.Now;
		public DateTime ReturnedOn { get; set; }

	}
}
