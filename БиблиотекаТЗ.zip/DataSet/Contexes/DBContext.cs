﻿
using DataAccess.Interfaces;
using DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataAccess.Contexes
{
	class DBContext
	{
		public class DB_Context : IDbContext
		{
			public void AddAuthor(Author author)
			{
				throw new NotImplementedException();
			}

			public void AddUser(string login, string password)
			{
				throw new NotImplementedException();
			}

			public void Add_Book(Book book)
			{
				throw new NotImplementedException();
			}

			public void DeleteAuthor(int id)
			{
				throw new NotImplementedException();
			}

			public void DeleteBook(int id)
			{
				throw new NotImplementedException();
			}

			public void DeleteUser(int id)
			{
				throw new NotImplementedException();
			}

			public List<Book> GetAllBooks()
			{
				throw new NotImplementedException();
			}

			public Book GetBook(int id)
			{
				throw new NotImplementedException();
			}

			public BookHistory GetBookHistory(int BookId)
			{
				throw new NotImplementedException();
			}

			public User GetUser(int id)
			{
				throw new NotImplementedException();
			}

			public List<User> GetUsers()
			{
				throw new NotImplementedException();
			}

			public void ReturnBookToLib(int BookId)
			{
				throw new NotImplementedException();
			}

			public void TakeBookFromLib(int BookId, int UserId)
			{
				throw new NotImplementedException();
			}

			public void UpdateBook(int oldIdBook, Book newBook)
			{
				throw new NotImplementedException();
			}
		

		  public SqlConnection connection { get; set; }
			public DB_Context() {
			  connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionStrings:DefaultConnection"].ConnectionString);
			}
			public DB_Context(string connectionString) {
				this.connectionString = connectionString;
			}
			//AddAuthor
			public void AddAuthor(string name, string lName)
			{
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					string sql = $"Insert into {nameof(Author)}({nameof(Author.Name)},{nameof(Author.LName)}) values('{name}','{lName}')";
					SqlCommand command = new SqlCommand(sql, connection);

					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						connection.Open();
						command.ExecuteNonQuery();
					}

				}
			}
			public void DeleteAuthor(int id)
			{
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					string sql = $"Delete From {nameof(Author)}s Where AuthorId='{id}'";
					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						connection.Open();
						command.ExecuteNonQuery();
					}
				}

			}

			//Add User 
			public void AddUser(string login, string password)
			{
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					string sql = $"Insert into Users(LogIn,Password) values('{login}','{password}')";
					SqlCommand command = new SqlCommand(sql, connection);

					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						connection.Open();
						command.ExecuteNonQuery();
						connection.Close();
					}

				}
			}
			public void DeleteUser(int id)
			{
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					string sql = $"Delete From {nameof(User)}s Where UserId='{id}'";
					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						connection.Open();
						command.ExecuteNonQuery();
					}
				}

			}

			//Get User from ID
			public User GetUser(int id)
			{
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					string sql = $"Select * From Users where UserId={id}"; SqlCommand command = new SqlCommand(sql, connection);
					User user = new User();

					using (SqlDataReader dataReader = command.ExecuteReader())
					{

						while (dataReader.Read())
						{
							user.Id = Convert.ToInt32(dataReader["UserId"]);
							user.LogIn = Convert.ToString(dataReader["LogIn"]);
							user.Password = Convert.ToString(dataReader["Password"]);
						}
					}
					return user;
				}
			}
			public List<User> GetUsers()
			{
				List<User> users = new List<User>();
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					string sql = "Select * From Users";
					SqlCommand command = new SqlCommand(sql, connection);
					User user = new User();
					using (SqlDataReader dataReader = command.ExecuteReader())
					{

						while (dataReader.Read())
						{
							user.Id = Convert.ToInt32(dataReader["UserId"]);
							user.LogIn = Convert.ToString(dataReader["LogIn"]);
							user.Password = Convert.ToString(dataReader["Password"]);
						}

					}
					users.Add(user);
				}
				return users;
			}
			public List<Book> GetAllBooks()
			{
				List<Book> bookList = new List<Book>();


				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					//SqlDataReader
					connection.Open();

					string sql = "Select * From Books"; SqlCommand command = new SqlCommand(sql, connection);
					string sql2 = "select Authors.[Name],Authors.LName from Authors" +
								" join Books on Books.BookId in (select BookId from AuthorsToBooks)" +
								" join AuthorsToBooks on AuthorsToBooks.AuthorId = Authors.AuthorId";
					SqlCommand command2 = new SqlCommand(sql2, connection);
					Book book = new Book();
					using (SqlDataReader dataReader = command.ExecuteReader())
					{

						while (dataReader.Read())
						{
							book.Id = Convert.ToInt32(dataReader["BookId"]);
							book.Name = Convert.ToString(dataReader["Name"]);

							book.IsAvalaible = dataReader.GetBoolean((int)dataReader["IsAvalaible"]);

						}
					}
					using (SqlDataReader dataReader = command2.ExecuteReader())
					{
						while (dataReader.Read())
						{
							book.Authors[0].Name = Convert.ToString(dataReader["Name"]); //?
							book.Authors[0].LName = Convert.ToString(dataReader["LName"]); //?
						}

					}
					bookList.Add(book);

					return bookList;
				}
			}
			public Book GetBook(int id)
			{
			
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					string sql = $"Select * From Books Where BookId='{id}'";
					SqlCommand command = new SqlCommand(sql, connection);
					//string sql2 = "select Authors.[Name],Authors.LName from Authors" +
					//		" join Books on Books.BookId in (select BookId from AuthorsToBooks)" +
					//		" join AuthorsToBooks on AuthorsToBooks.AuthorId = Authors.AuthorId";
					string sql2 = "select Authors.[Name],Authors.LName from Authors" +
						" where AuthorId =(select AuthorId from AuthorsToBooks where BookId = (select BookId from Books))";
					SqlCommand command2 = new SqlCommand(sql2, connection);
					connection.Open();
					Book book = new Book();
					using (SqlDataReader dataReader = command.ExecuteReader())
					{
						while (dataReader.Read())
						{
							book.Id = Convert.ToInt32(dataReader["BookId"]);
							book.Name = Convert.ToString(dataReader["Name"]);
						}
					}
					using (SqlDataReader dataReader = command2.ExecuteReader())
					{
						while (dataReader.Read())
						{
							book.Authors[0].Name = Convert.ToString(dataReader["Name"]); //?
							book.Authors[0].LName = Convert.ToString(dataReader["LName"]); //?
						}

					}
					return book;
				}
			}
		
			public void UpdateBook(int oldIdBook, Book newBook)
			{
				 
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					
					string sql = $"Update {nameof(Book)}s SET BookName='{bookName}','{IsAvalaible}' Where Id='{book.Id}'";
					string sql2 = $"Update Authors SET {nameof(Author}.[Name]={book.Authors[0].Name},Authors.LName ={book.Authors[0].Name} Where AuthorId =" +
							"(select AuthorId from AuthorsToBooks where BookId = (select BookId from Books))";


					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						connection.Open();
						command.ExecuteNonQuery();
				
					}
					using (SqlCommand command = new SqlCommand(sql2, connection))
					{
						connection.Open();
						command.ExecuteNonQuery();
			
					}
				}
			}

			public void TakeBookFromLib(int BookId, int UserId)//?
			{
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					//sql different date format
					string sql = $"insert into UsersToBooks (BookId,UserId,TimeTaken) values ('{BookId}','{UserId}','{DateTime.Now.Date}')";
					string sql2 = $"update {nameof(Book)}s set IsAvalaible=0 where BookId='{BookId}'";
					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						connection.Open();
						command.ExecuteNonQuery();
						connection.Close();
					}
					using (SqlCommand command = new SqlCommand(sql2, connection))
					{
						connection.Open();
						command.ExecuteNonQuery();
						connection.Close();
					}
				}
			}
			public void ReturnBookToLib(int BookId)//?
			{

				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					//sql different date format!!!
					string sql = $"update UsersToBooks set TimeReturned = '{DateTime.Now.Date}' where BookId={BookId}";
					string sql2 = $"update {nameof(Book)}s set IsAvalaible='1' where BookId='{BookId}'";
					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						connection.Open();
						command.ExecuteNonQuery();
						connection.Close();
					}
				}

			}

			//GetBookHistory
			public BookHistory GetBookHistory(int BookId)
			{
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					//sql different date format!!!
					string sql = "select b.BookId,b.[Name],u.UserId,u.Login,TimeTaken,TimeReturned from UsersToBooks " +
								 $"left join {nameof(Book)}s as b on b.BookId ={BookId} " +
								$"left join {nameof(User)}s as u on u.UserId = UsersToBooks.UserId";
					BookHistory bookHistory = new BookHistory();
					SqlCommand command = new SqlCommand(sql, connection);
					connection.Open();
					using (SqlDataReader dataReader = command.ExecuteReader())
					{
						while (dataReader.Read())
						{
							bookHistory.BookId = Convert.ToInt32(dataReader["BookId"]);
							bookHistory.BookName = Convert.ToString(dataReader["Name"]);
							bookHistory.UserId= Convert.ToInt32(dataReader["UserId"]);
							bookHistory.UserLogIn = Convert.ToString(dataReader["LogIn"]);
							bookHistory.TakenOn = Convert.ToDateTime(dataReader["TimeTaken"]);
							bookHistory.ReturnedOn = Convert.ToDateTime(dataReader["TimeReturned"]);
						}
					}
					return bookHistory;
				}
			
			}

			public void Add_Book(Book book)
			{
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					string sql = $"Insert Into {nameof(Book)}s (Name) Values ('{book.Name}')";
					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						command.CommandType = CommandType.Text;
						connection.Open();
						command.ExecuteNonQuery();
					}
					string sql2 = $"Insert Into {nameof(Author)}s (Name,LName) Values ('{book.Authors[0].Name}','{book.Authors[0].LName}')";
					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						command.CommandType = CommandType.Text;
						connection.Open();
						command.ExecuteNonQuery();
					}
					string sql3 = $"Insert Into AuthorsToBooks (BookId,AuthorId) Values ('{book.Id}','{book.Authors[0].Id}')";
					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						command.CommandType = CommandType.Text;
						connection.Open();
						command.ExecuteNonQuery();
						connection.Close();
					}

				}

			}


			public void DeleteBook(int id)
			{
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					string sql = $"Delete From {nameof(Book)}s Where BookId='{id}'";
					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						connection.Open();
						command.ExecuteNonQuery();
					}
				}

			}






		}
	}
}




			//вынести connectionString в appconfig
			//2 конструктора - по -умолчанию загружает conn string from appconfig 
			// constructor takes 1 string params
			//remove lists and add a method like DropCreateDBAlways  --> this method cheks if db exists otherwise create it 
			// create a method like initialize --> it should create tables with default data (test data)
			//crete methods Create(Book book),Update(OldBook,newBook),Delete(Id),Get(id), GetAll for following models :Author,Book, User  
			// create field SQL COnnection 
		//create interface IDB_context 
			
		
