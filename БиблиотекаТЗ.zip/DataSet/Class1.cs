﻿using System;

namespace DataSet
{
	public class Class1
	{
	}
}
