﻿
using BusinessLogic.Infrastructure;
using BusinessLogic.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;

namespace WebProject.Controllers
{
    public class UserController : Controller
    {
        public UserController(IUserService userService, IAdminService adminService)
        {
            this.userService = userService;
            this.adminService = adminService;
        }

        
        private IUserService userService { get; }
        private IAdminService adminService { get; }
        //all books view
        public ActionResult Index()
        {
            return View(adminService.GetBooks());
        }
        // BooksAvailable view
        public ActionResult BooksAvailable()
        {
            return View(adminService.GetAllAvailable());
        }
        //BooksTaken view
        public ActionResult BooksTaken()
        {
            var hash = Request.Cookies["Auth"];
            if (string.IsNullOrEmpty(hash))
                return BadRequest();
            var userId = userService.GetUserIdFromHash(hash);
            var user = userService.GetUser(userId);
            return View(user.BooksTaken);
             
        }

       
        public ActionResult TakeBook()
        {
            return View();
        }
        //take book post method
        [HttpPost]
        public ActionResult TakeBook(int? id)
        {
            try
            {
                var hash = Request.Cookies["Auth"];
                if (string.IsNullOrEmpty(hash))
                    return BadRequest();

                var userId = userService.GetUserIdFromHash(hash);
                userService.TakeBookFromLib(id, userId);

                return RedirectToAction(nameof(Index));
            }
            catch (ValidationException ex)
            {
                return Content(ex.Message);
            }
        }

        public ActionResult ReturnBook(int? bookId)
        {
            return View();
        }
        //return book post method
        [HttpPost]
        public ActionResult ReturnBook(int? id, int? userId)
        {
            try
            {
                var hash = Request.Cookies["Auth"];
                if (string.IsNullOrEmpty(hash))
                    return BadRequest();

                var userid = userService.GetUserIdFromHash(hash);
                userService.ReturnBookToLib(id, userid);

                return RedirectToAction(nameof(Index));
            }
            catch (ValidationException ex)
            {
                return Content(ex.Message);
            }
        }
        //redirect to login/logout
        public  ActionResult LogOut()
        {
            return Redirect("/Login/LogOut");
        }
    }
}