﻿using System;
using System.Linq;
using BusinessLogic.DataTransferObjects;
using BusinessLogic.Infrastructure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebProject.Controllers
{
    public class LoginController : Controller
    {
        public LoginController(IUserService userService)
        {
            this.userService = userService;
        }

        private IUserService userService { get; }
        //get login page
        public IActionResult Index()
        {
            return View();
        }
        //login method
        [HttpPost]
        public IActionResult Index(UserDTO user)
        {
            try
            {
                var users = userService.GetUsers();
                var currentUser = users.FirstOrDefault(x => x.LogIn == user.LogIn && x.Password == user.Password);

                if (currentUser == null) return Content("no user found");
                Response.Cookies.Append("Auth", userService.GetHashFromUserId(currentUser.Id));
                if(currentUser.IsAdmin==false) return Redirect("/User/Index");
                else return Redirect("/Book/Index");
            }
            catch (ValidationException ex)
            {
                return NotFound(ex.Message);
            }
        }
        //registration view
        public IActionResult Register()
        {
            return View();
        }
        //registration method
        [HttpPost]
        public IActionResult Register(UserDTO user)
        {
            try
            {
                userService.AddUser(user);
                return Redirect("Index");
            }
            catch (ValidationException ex)
            {
                return Content(ex.Message);
            }
        }
        //log out
        public IActionResult LogOut()
        {
            Response.Cookies.Append("Auth", "", new CookieOptions() { Expires = DateTime.Now.AddDays(-1) });
            return View("Index");
        }
    }
}