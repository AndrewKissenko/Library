﻿
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using BusinessLogic.DataTransferObjects;
using BusinessLogic.Interfaces;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebProject.Controllers
{
    public class BookController : Controller
    {
        public BookController(IAdminService adminService)
        {
            this.adminService = adminService;
        }

        private IAdminService adminService { get; }
        //show all books
        public ActionResult Index()
        {
            return View(adminService.GetBooks());
        }

        //get book history when and by whom was taken and returned
        public ActionResult Details(int? id)
        {
            if (id != null)
                try
                {
                    var book = adminService.GetBook(id);
                    return View(book);
                }
                catch (ValidationException ex)
                {
                    return Content(ex.Message);
                }

            return NotFound();
        }

        // GET: Book/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Book/Create
        [HttpPost]
        public ActionResult Create([FromBody]BookDTO book)
         {

            try
            {
                adminService.AddBook(book);
                return RedirectToAction(nameof(Index));
            }
            catch
            { 
                return View();
            }
        }

        // GET: Book/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id != null)
            {
                var book = adminService.GetBook(id);
                if (book != null)

                    return View(book);
            }

            return NotFound();
        }

        // POST: Book/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int? id, BookDTO book)
        {
            try
            {
                adminService.UpdateBook(book.Id, book);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Book/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id != null)
            {
                var book = adminService.GetBook(id);
                if (book != null)
                    return View(book);
            }

            return NotFound();
        }

        // POST: Book/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int? id, IFormCollection collection)
        {
            try
            {
                if (id != null) adminService.RemoveBook(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        //sign out 
        public ActionResult LogOut()
        {
            return Redirect("/Login/LogOut");
        }
    }
}