﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using DataAccess.Models;

namespace BusinessLogic.DataTransferObjects
{
    public class BookDTO
    {
        public BookDTO()
        {
            Authors = new List<Author>();
            BookHistories = new List<BookHistoryDTO>();
        }

        public int Id { get; set; }

        [Required]
        [Display(Name = "Book Name")]
        public string Name { get; set; }

        public bool IsAvalaible { get; set; }
        public List<Author> Authors { get; set; }
        public List<BookHistoryDTO> BookHistories { get; set; }
    }
}