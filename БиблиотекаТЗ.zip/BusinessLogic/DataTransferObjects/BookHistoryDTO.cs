﻿using System;

namespace BusinessLogic.DataTransferObjects
{
    public class BookHistoryDTO
    {
        public int BookId { get; set; }
        public string BookName { get; set; }
        public int UserId { get; set; }
        public string UserLogIn { get; set; }
        public DateTime TakenOn { get; set; }
        public string ReturnedOn { get; set; }
    }
}