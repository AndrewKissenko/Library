﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using DataAccess.Models;

namespace BusinessLogic.DataTransferObjects
{
    public class UserDTO
    {
        public int Id { get; set; }

        [Required] [Display(Name = "Email")] public string LogIn { get; set; }

        [Required]
        [Display(Name = "Password")]
        public string Password { get; set; }

        public List<BookDTO> BooksTaken { get; set; } = new List<BookDTO>();
        public bool IsAdmin { get; set; }
    }
}