﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using DataAccess.Models;

namespace BusinessLogic.DataTransferObjects
{
    public class AuthorDTO
    {
        public int Id { get; set; }

        [Required] [Display(Name = "Name")] public string Name { get; set; }

        [Required]
        [Display(Name = "Last name")]
        public string LName { get; set; }

        public List<Book> Books { get; set; }
    }
}