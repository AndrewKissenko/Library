﻿using AutoMapper;
using BusinessLogic.DataTransferObjects;
using DataAccess.Models;

namespace BusinessLogic.Adapter
{
    //class to init mappers
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<User, UserDTO>();
            CreateMap<UserDTO, User>();
            CreateMap<Book, BookDTO>();
            CreateMap<BookDTO, Book>();
            CreateMap<BookHistory, BookHistoryDTO>();
            CreateMap<Author, AuthorDTO>();
            CreateMap<AuthorDTO, Author>();
        }
    }
}