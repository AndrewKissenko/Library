﻿using DataAccess.Interfaces;
using DataAccess.Repositories;
using Microsoft.Extensions.DependencyInjection;

namespace BusinessLogic.Util
{
    //initialize dependency injection 
    public static class BusinessModule
    {
        public static void RegisterBusinessServices(this IServiceCollection services, string connection)
        {
            services.AddTransient<IUnitOfWork>(options => new DBUnitOfWork(connection));
        }
    }
}