﻿using System.Net;
using System.Net.Mail;

namespace BusinessLogic.Util
{   
    //functionality to send mails to users when they take books
    public static class SmtpMailSender
    {
        private const string SendlerEmail = "andrewkisenko1@gmail.com";
        private const string SendlerPass = "0978429571"; //probably it is not safe
        private const string Host = "smtp.gmail.com";
        private const int Port = 587;

        public static void SendMail(string email, string bookName)
        {
            var from = new MailAddress(SendlerEmail, "City Library");
            var to = new MailAddress(email);
            var mail = new MailMessage(from, to)
            {
                Subject = "Book",
                Body = $"<h2>You took {bookName} in our library</h2>",
                IsBodyHtml = true
            };
            var smtp = new SmtpClient(Host, Port)
            {
                Credentials = new NetworkCredential(SendlerEmail, SendlerPass),
                EnableSsl = true
            };
            smtp.Send(mail);
        }
    }
}