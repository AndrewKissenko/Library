﻿using System.Collections.Generic;
using BusinessLogic.DataTransferObjects;

namespace BusinessLogic.Interfaces
{
    public interface IAuthorService
    {
        int AddAuthor(AuthorDTO author);
        void DeleteAuthor(int? id);
        IEnumerable<AuthorDTO> GetAuthors();
    }
}