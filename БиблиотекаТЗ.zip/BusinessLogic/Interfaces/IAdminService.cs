﻿using System.Collections.Generic;
using BusinessLogic.DataTransferObjects;

namespace BusinessLogic.Interfaces
{
    public interface IAdminService
    {
        void AddBook(BookDTO book);
        void RemoveBook(int? id);
        BookDTO GetBook(int? id);
        void UpdateBook(int? oldIdBook, BookDTO newBook);
        IEnumerable<BookDTO> GetBooks();
        IEnumerable<BookDTO> GetAllAvailable();
    }
}