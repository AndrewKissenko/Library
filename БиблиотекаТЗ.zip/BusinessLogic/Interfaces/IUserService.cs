﻿using System.Collections.Generic;
using BusinessLogic.DataTransferObjects;
using DataAccess.Models;

namespace BusinessLogic.Infrastructure
{
    public interface IUserService
    {
        void TakeBookFromLib(int? BookId, int? UserId);
        void ReturnBookToLib(int? BookId, int? UserId);
        IEnumerable<UserDTO> GetUsers();
        UserDTO GetUser(int? id);
        void AddUser(UserDTO user);
        string GetHashFromUserId(int userId);
        int GetUserIdFromHash(string hash);
    }
}