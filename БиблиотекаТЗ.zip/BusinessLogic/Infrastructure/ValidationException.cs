﻿using System;

namespace BusinessLogic.Infrastructure
{
    //class to validate occuring exceptions and errors
    public class ValidationException : Exception
    {
        public ValidationException(string message, string prop) : base(message)
        {
            Property = prop;
        }

        public string Property { get; protected set; }
    }
}