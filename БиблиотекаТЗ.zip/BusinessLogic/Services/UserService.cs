﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using AutoMapper;
using BusinessLogic.DataTransferObjects;
using BusinessLogic.Infrastructure;
using BusinessLogic.Util;
using DataAccess.Interfaces;
using DataAccess.Models;

namespace BusinessLogic.Services
{
    //service to operate users
    public class UserService : IUserService
    {
        public UserService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            UnitOfWork = unitOfWork;
            this.Mapper = mapper;
        }

        private IUnitOfWork UnitOfWork { get; }
        private IMapper Mapper { get; set; }
        //functionality to take book from lib
        public void TakeBookFromLib(int? BookId, int? UserId)
        {
            if (BookId == null || UserId == null) throw new ValidationException("inner error occurred", null);
            var user = UnitOfWork.Users.Get(UserId.Value);
            var book = UnitOfWork.Books.Get(BookId.Value);

            if (book.IsAvalaible == false) throw new ValidationException("The book is not avalaible!", null);
           
            UnitOfWork.UserBookOperations.TakeBookFromLib(BookId.Value, UserId.Value);
            SmtpMailSender.SendMail(user.LogIn, book.Name);
        }
        //functionality to return book to lib
        public void ReturnBookToLib(int? BookId, int? UserId)
        {
            if (BookId == null) throw new ValidationException("wrong id", null);
            var user = UnitOfWork.Users.Get(UserId.Value); 
            var book = UnitOfWork.Books.Get(BookId.Value);
            bool isNotTaken= true;
            foreach (var b in user.BooksTaken) {
                if (b.Id != BookId) isNotTaken = true;
                else { isNotTaken = false; break; }
            }
            if(isNotTaken==true) throw new ValidationException("you cannot return this book", null);
            if (book.IsAvalaible) throw new ValidationException("you didn't take this book", null);
            UnitOfWork.UserBookOperations.ReturnBookToLib(BookId.Value, UserId.Value);
            
        }
        //get user list
        public IEnumerable<UserDTO> GetUsers()
        {
            return Mapper.Map<IEnumerable<UserDTO>>(UnitOfWork.Users.GetAll());
        }
        //get user
        public UserDTO GetUser(int? id)
        {
            if (id == null) throw new ValidationException("wrong id", null);
            return Mapper.Map<UserDTO>(UnitOfWork.Users.Get(id.Value));
        }
        //add a new user to db
        public void AddUser(UserDTO user)
        {
              UnitOfWork.Users.Add(Mapper.Map<User>(user));
        }
        //create a hash code from  id
        public string GetHashFromUserId(int id)
        {
            return Encryptor.Encrypt(id.ToString());
        }
        //convert back from hash code to user id
        public int GetUserIdFromHash(string hash)
        {
            return  Convert.ToInt32(Encryptor.Decrypt(hash));
        }
       
    }
}