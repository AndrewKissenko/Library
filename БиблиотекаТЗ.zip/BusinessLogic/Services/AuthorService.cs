﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using AutoMapper;
using BusinessLogic.DataTransferObjects;
using BusinessLogic.Interfaces;
using DataAccess.Interfaces;
using DataAccess.Models;

namespace BusinessLogic.Services
{
    //service to work with authors
    public class AuthorService : IAuthorService
    {
        public AuthorService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            UnitOfWork = unitOfWork;
            this.Mapper = mapper;
        }
        private IUnitOfWork UnitOfWork { get; }
        private IMapper Mapper { get; set; }
        //add author
        public int AddAuthor(AuthorDTO author)
        {
            if (author == null) throw new ValidationException("wrong author input", null);

            UnitOfWork.Authors.Add(Mapper.Map<Author>(author));
            return 0;
        }
        //delete author
        public void DeleteAuthor(int? id)
        {
            if (id == null) throw new ValidationException("wrong id", null);
            UnitOfWork.Authors.Remove(id.Value);
        }
        //get all authors
        public IEnumerable<AuthorDTO> GetAuthors()
        {
            return Mapper.Map<IEnumerable<AuthorDTO>>(UnitOfWork.Authors.GetAll());
        }
    }
}