﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using AutoMapper;
using BusinessLogic.DataTransferObjects;
using BusinessLogic.Interfaces;
using DataAccess.Interfaces;
using DataAccess.Models;

namespace BusinessLogic.Services
{
    //service to operate and manage books
    public class AdminService : IAdminService
    {
        private IUnitOfWork UnitOfWork { get; }
        private IMapper Mapper { get; set; }

        public AdminService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            UnitOfWork = unitOfWork;
            this.Mapper = mapper;
        }
        //map from BookDTO to Book and add this book to db
        public void AddBook(BookDTO book)
        {
            if (book == null) throw new ValidationException("wrong book", null);
            UnitOfWork.Books.Add(Mapper.Map<Book>(book));
        }
        //delete book by ID
        public void RemoveBook(int? id)
        {
            if (id == null) throw new ValidationException("wrong id", null);
            UnitOfWork.Books.Remove(id.Value);
        }
        //get book by ID
        public BookDTO GetBook(int? id)
        {
            if (id == null) throw new ValidationException("wrong id", null);
            return Mapper.Map<BookDTO>(UnitOfWork.Books.Get(id.Value));
        }
        // map and update book 
        public void UpdateBook(int? oldIdBook, BookDTO newBook)
        {
            if (oldIdBook == null) throw new ValidationException("wrong id", null);
            UnitOfWork.Books.UpdateBook(oldIdBook.Value, Mapper.Map<Book>(newBook));
        }



        public IEnumerable<BookDTO> GetBooks()
        {
            return Mapper.Map<IEnumerable<BookDTO>>(UnitOfWork.Books.GetAll());
        }
        public IEnumerable<BookDTO> GetAllAvailable()
        {
            return Mapper.Map<IEnumerable<BookDTO>>(UnitOfWork.Books.GetAllAvailable());
        }
    }
}

